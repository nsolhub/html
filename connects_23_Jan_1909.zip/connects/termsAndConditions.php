<?php include('header.php'); ?>

	<!-- start banner Area -->
	<section class="banner-area">
		<div class="container">
			<div class="row banner-content">
			</div>
		</div>
		</div>
	</section>
	<!-- End banner Area -->


	<!-- Start about Area -->
	<section class="about-area" style="padding-top: 1px;">
<div class="container">
			<div class="row align-items-center">
			
				<div class="offset-lg-1 col-lg-8 home-about-right">
					<h1>
							Terms And Conditions
						</h1>
						<p>The terms and conditions of CONNECTS, a free app of NIKU SOLUTIONS PTE LTD is listed here. It is primarily a public app that is used to facilitate users with their daily life problems (i.e. Service Providers can offer their services &Customers can hire a suitable service provider of their choice). You can avail this service by accepting these conditions. Read them carefully</p>
						<h2>Privacy</h2>
						<p>
						Kindly review our detailed privacy policy for a thorough understanding of our practices.</p>
						<h2>Copyright information</h2>
						<p>All the content included in this app such as text, graphics, images, and data compilations are all the property of CONNECTS or its content suppliers that are protected in the light of international copyright laws.</p>
						<h2>Jobs and Services</h2>
						<p>
						Service Providers can join service categories which they can provide to customers &Customers can post a Job on the bases of their needs & requirements. Service Providers can apply for jobs posted by customers & customers can approve or reject any request by service providers.</p>
						<h2>Liability Disclosure </h2>
						<p>We do not sell products and services through this mobile app. We may suspend access to our services immediately without prior notice or liability if you breach the Terms and Conditions. For any material changes to the Terms and Conditions will be notified to you in advance so that terms and conditions became effective.</p>
						<div class="col-md-10 offset-1">
						<ul style="list-style: disc;">
							<li>Company does not offer any guarantee or security against services provided by registered ‘Service Providers OR Vendors’ on this application.</li>
							<li>Company is not responsible for any damage caused by any user to another user on this application.</li>
						</ul>

					
				</div>
			</div>
		</div>
	</section>
	<!-- End about Area -->

	

<?php include('footer.php'); ?>