<?php include("header.php");?>

	<!-- start banner Area -->
	<section class="home-banner-area">
		<div class="container">
			<div class="row fullscreen d-flex align-items-center justify-content-between">
				<div class="home-banner-content col-lg-6 col-md-6">
					<h1>
						Make Life  <br> Easier With ‘Connects’  
					</h1>
					<p>Need something to done? Find the best service providers </p>
					<p>And assign job to selected ones.</p>
					<div class="download-button d-flex flex-row justify-content-start">
						<div class="buttons flex-row d-flex">
							<i class="fa fa-apple" aria-hidden="true"></i>
							<div class="desc">
								<a href="#">
									<p>
										<span>Available</span> <br>
										on App Store
									</p>
								</a>
							</div>
						</div>
						<div class="buttons dark flex-row d-flex">
							<i class="fa fa-android" aria-hidden="true"></i>
							<div class="desc">
								<a href="#">
									<p>
										<span>Available</span> <br>
										on Play Store
									</p>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="banner-img col-lg-4 col-md-6">
					<div id="myTurntable" class="turntable">
					  <ul>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    
					    </ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End banner Area -->

	<!-- Start fact Area -->
	<section id="about" class="fact-area">
		<div class="container">
			<div class="fact-box">
				<div class="row align-items-center">
					<div class="col single-fact">
						<h2>100+</h2>
						<p>Service Providers</p>
					</div>
					<div class="col single-fact">
						<h2>50+</h2>
						<p>Service Categories</p>
					</div>
					<div class="col single-fact">
						<h2>100+</h2>
						<p>Daily Installations</p>
					</div>
					<div class="col single-fact">
						<h2>100%</h2>
						<p>Pakistani App</p>
					</div>
					<div class="col single-fact">
						<h2>100%</h2>
						<p>Unique Idea</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End fact Area -->

	<!-- Start feature Area -->
	<section class="feature-area section-gap-top">
		<div class="container">
			<div class="row d-flex justify-content-center">
				<div class="col-lg-6">
					<div class="section-title text-center">
						<h2>How this service works?</h2>
						<p>Connects aims to solve your daily life problems by facilitatingYou and‘Service Providers’with a platform, where you can easily Hire a service provider (i.e. Plumber for Senatory work) for any required job.
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End feature Area -->

	<!-- Start about Area -->
	<section id="features" class="about-area">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-5 home-about-left">
					<div id="myTurntable1" class="turntable">
					  <ul>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    
					    </ul>
					</div>
				</div>
				<div class=" col-lg-5 offset-1 col-md-10 home-about-right">
					<h2 style="color: #949494;"> Service Provider </h2>
					<ol style="list-style: decimal; font-size: 27px; line-height: 50px;">
						<li>
					<strong>Choose Services</strong>
					Select Services which you’re good in. Select Area (City/ Colony/ Sector) & provide other details.</li>
					<li>
					<strong>Apply on Jobs</strong>
					Browse available jobs around you & apply for one you’re interested in.</li>
					<li>
					<strong>Earn from Jobs</strong>
					Once You’re selected by Customers – Complete the JOB & Receive Your Hard Earned Money.</li>
				</ol>

					<a class="primary-btn text-uppercase" href="#">Get Details</a>
				</div>
				<div class="col-lg-5 offset-1 home-about-right home-about-right2">
					<h2 style="color: #949494;"> Customer </h2>
					<ol style="list-style: decimal; font-size: 27px; line-height: 50px;">
						<li>
					<strong>Create Jobs</strong>
					Need something to be done by professionals? Provide Details with Photo & other information.</li>
					<li>
					<strong>Accept  Applications</strong>
					Accept bids by service providers on your posted jobs & choose the desired one.</li>
					<li>
					<strong>Problem Solved</strong>
					Pay service provider with his / her reward once your job is done.</li>
				</ol>
					
				</div>
				<div class="col-lg-5 home-about-left">
					<div id="myTurntable12" class="turntable">
					  <ul>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    <li data-img-src="img/03.png"></li>
					    <li data-img-src="img/banner-img.png"></li>
					    <li data-img-src="img/iphone.png"></li>
					    
					    </ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End about Area -->
	<section id="download" class="feature-area about-area section-gap-top">
			<div class="container">
				<div class="row d-flex justify-content-center">
					
						<div class="download-button d-flex flex-row justify-content-start">
						<div class="buttons flex-row d-flex">
							<i class="fa fa-apple" aria-hidden="true"></i>
							<div class="desc">
								<a href="#">
									<p>
										<span>Available</span> <br>
										on App Store
									</p>
								</a>
							</div>
						</div>
						<div class="buttons dark flex-row d-flex">
							<i class="fa fa-android" aria-hidden="true"></i>
							<div class="desc">
								<a href="#">
									<p>
										<span>Available</span> <br>
										on Play Store
									</p>
								</a>
							</div>
						</div>
						</div>
					
					
				</div>
			</div>
	</section>	

	

	

	
<?php include('footer.php'); ?>
<script type="text/javascript">
			$('#myTurntable').turntable({
		      axis: 'scroll',
		      
		    });
		    $('#myTurntable1').turntable({
		      axis: 'scroll',
		      
		    });
		    $('#myTurntable12').turntable({
		      axis: 'scroll',
		      
		    });

		</script>