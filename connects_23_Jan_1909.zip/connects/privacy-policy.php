<?php include('header.php'); ?>

	<!-- start banner Area -->
	<section class="banner-area">
		<div class="container">
			<div class="row banner-content">
			</div>
		</div>
		</div>
	</section>
	<!-- End banner Area -->


	<!-- Start about Area -->
	<section class="about-area" style="padding-top: 1px;">
<div class="container">
			<div class="row align-items-center">
			
				<div class="offset-lg-1 col-lg-8 home-about-right">
					<h1>
							Privacy Policy
						</h1>
						<div style="" class=" privacy_content ">
            <p>NIKU SOLUTIONS PTE LTD built the CONNECTS app as a free app. This SERVICE is provided by NIKU SOLUTIONS PTE LTD at no cost and is intended for use as is.</p>
            <p>This page is used to inform visitors regarding our policies with the collection, use, and disclosure of Personal Information if anyone decided to use our Service. </p>

            <p>If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is used for providing and improving the Service. We will not use or share your information with anyone except as described in this Privacy Policy </p>

            <p> The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at CONNECTS unless otherwise defined in this Privacy Policy.</p>
            <h2 style="padding: 40px 1px; font-size: 40px;"> INFORMATION COLLECTION AND USE</h2>

            <p>We collect different types of information for our service that is given below: </p>
            <h3>Personal Data </h3>

            <p> For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information, including but not limited to Email Address, First name and Last name, Phone number, Network Access, Access Fine Location, Gallery, and Camera. The information that we request will be retained by us and used as described in this privacy policy.</p>

            <p>The app does use third-party services that may collect information used to identify you. </p>

            <p>Links to the privacy policy of third party service providers used by the app are: </p>
            <div class="col-md-9 offset-1">
	            <ul style="list-style: disc">
	              <li>Google Play Services</li>
	              <li> AdMob  </li>
	              <li> Firebase Analytics </li>
	              <li> Facebook </li>
	              <li> Clicky  </li>
	            </ul>
	            </p>
        	</div>
            <h3> Log Data</h3>
            <p>We want to inform you that whenever you use our Service, in the case of an error in the app we collect data and information (through third-party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol ("IP") address, device name, operating system version, the configuration of the app when utilizing our Service, the time and date of your use of the Service, and other statistics. </p>
            <h3> Cookies</h3>
            <p>Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device's internal memory. </p>

            <p>This Service does not use these “cookies” explicitly. However, the app may use third party code and libraries that use “cookies” to collect information and improve their services. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service. </p>
            <h3>Examples of Cookies we use</h3>
            <p><strong>Session Cookies:</strong> We use Session Cookies to store information in the form of session identification for the operation of service. </p>

            <p><strong>Preference Cookies:</strong> We use preference Cookies to allow the app to remember your preferred information </p>

            <p><strong>Security Cookies:</strong> We use security cookies to authenticate users, prevent the false use of login credentials and protect users for unauthorized access. </p>
            <h2 style="padding: 50px 1px;">DISCLOSURE OF DATA</h2>
            <h3> SERVICE PROVIDERS</h3>
            <p>We may employ third-party companies and individuals due to the following reasons: 
            <div class="col-md-9 offset-1">
	            <ul style="list-style: disc">
	              <li> To facilitate our Service;</li>
	              <li>   To provide the Service on our behalf;  </li>
	              <li>   To perform Service-related services </li>
	              <li>   To assist us in analyzing how our Service is used. </li>
	            </ul>
	            </p>
       		</div>
            <p>We want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose. </p>
            <h3>DATA SECURITY</h3>
            <p>We value your trust in providing us with your Personal Information, thus we are striving to use commercially acceptable means of protecting it. Always remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security. </p>
            <h3>LINKS TO OTHER SITES</h3>

            <p>This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by us. Therefore, we strongly advise you to review the Privacy Policy of these websites. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services. </p>

            <p> </p>
            <h3>CHILDREN’S PRIVACY</h3>

            <p>These Services do not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. In the case we discover that a child under 13 has provided us with personal information, we immediately take the step to remove that information from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact us so that we will be able to do necessary actions. </p>
            <h3>CHANGES TO THIS PRIVACY POLICY</h3>

            <p>We may update our Privacy Policy from time to time. Thus, you are advised to review privacy policy periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately after they are posted on this page. </p>
            <h3>CONTACT US</h3>
            <p>If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us. </p>

            <p>Email: <a href="mailto:support@connects.pk">support@connects.pk</a></p>

            <p> </p>

            <p> </p>

            <p> </p>


          </div>

					
				</div>
			</div>
		</div>
	</section>
	<!-- End about Area -->

	

<?php include('footer.php'); ?>